from __future__ import annotations

import math
import os
import secrets
import sqlite3
import time
from contextlib import closing
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, g, jsonify, request, send_from_directory, session
from werkzeug.security import check_password_hash

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
DB_FILE = BASE_DIR / "startup_hours.db"

app = Flask(
    __name__,
    static_folder=str(PUBLIC_DIR),
    static_url_path="/static",
)

app.config.update(
    SECRET_KEY=os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=False,
)

USERS = {
    "user": {"role": "user", "password_hash": os.environ.get("USER_PASSWORD_HASH", "")},
    "admin": {"role": "admin", "password_hash": os.environ.get("ADMIN_PASSWORD_HASH", "")},
}

ALLOWED_CATEGORIES = {
    "Engineering / Development", "Design", "Research & Experimentation",
    "Product / Strategy", "Marketing / Growth", "Ops / Admin / Legal",
    "Fundraising / Investor Relations", "Customer / Sales",
}
ALLOWED_CLASSIFICATIONS = {"sweat", "bill", "internal"}
ALLOWED_RD = {"no", "yes", "maybe"}
ALLOWED_STATUS = {"Unpaid", "Invoiced", "Paid (W-2)", "Paid (1099)", "Converted to equity"}
ALLOWED_RATE_BASIS = {
    "Market replacement rate", "Personal W-2 rate (sanity check)",
    "Contractor / 1099 rate", "Agreed equity-value rate",
}
ALLOWED_CONFIDENCE = {
    "High — from contemporaneous log",
    "Medium — from calendar/commits",
    "Low — reconstructed estimate",
}

LOGIN_ATTEMPTS = {}
LOGIN_WINDOW_SECONDS = 300
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 60


def json_error(message, status=400):
    return jsonify({"error": message}), status


def get_db():
    if "db" not in g:
        db = sqlite3.connect(DB_FILE, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        db.execute("PRAGMA journal_mode = WAL")
        g.db = db
    return g.db


@app.teardown_appcontext
def close_db(_exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(DB_FILE)) as db:
        db.execute("PRAGMA journal_mode = WAL")
        db.executescript("""
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                name TEXT NOT NULL DEFAULT '',
                founder TEXT NOT NULL DEFAULT '',
                default_rate REAL NOT NULL DEFAULT 85,
                start_date TEXT NOT NULL DEFAULT '2026-03-01'
            );

            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY,
                date TEXT NOT NULL,
                start_time TEXT NOT NULL DEFAULT '',
                end_time TEXT NOT NULL DEFAULT '',
                hours REAL NOT NULL,
                project TEXT NOT NULL DEFAULT '',
                task TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL,
                classification TEXT NOT NULL,
                rate REAL NOT NULL,
                rate_basis TEXT NOT NULL,
                rd TEXT NOT NULL,
                status TEXT NOT NULL,
                confidence TEXT NOT NULL,
                evidence TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_entries_date ON entries(date);
            CREATE INDEX IF NOT EXISTS idx_entries_project ON entries(project);
            CREATE INDEX IF NOT EXISTS idx_entries_classification ON entries(classification);
            CREATE INDEX IF NOT EXISTS idx_entries_rd ON entries(rd);

            INSERT OR IGNORE INTO settings (id) VALUES (1);
        """)
        db.commit()


def finite_number(value, field_name):
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be a number.") from exc
    if not math.isfinite(number):
        raise ValueError(f"{field_name} must be finite.")
    return number


def validate_date(value):
    if not isinstance(value, str):
        return False
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def validate_time(value):
    if value in ("", None):
        return True
    if not isinstance(value, str):
        return False
    try:
        datetime.strptime(value, "%H:%M")
        return True
    except ValueError:
        return False


def clean_text(value, field_name, max_length):
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be text.")
    value = value.strip()
    if len(value) > max_length:
        raise ValueError(f"{field_name} is too long.")
    return value


def normalize_entry(entry):
    if not isinstance(entry, dict):
        raise ValueError("Entry must be a JSON object.")

    entry_id = clean_text(entry.get("id"), "ID", 100)
    if not entry_id:
        entry_id = secrets.token_hex(16)

    date = entry.get("date")
    if not validate_date(date):
        raise ValueError("Date must be YYYY-MM-DD.")

    if not validate_time(entry.get("start")) or not validate_time(entry.get("end")):
        raise ValueError("Start/end time must be HH:MM.")

    hours = finite_number(entry.get("hours"), "Hours")
    rate = finite_number(entry.get("rate"), "Rate")

    if hours < 0 or hours > 24:
        raise ValueError("Hours must be between 0 and 24.")
    if rate < 0 or rate > 500:
        raise ValueError("Rate must be between $0 and $500/hr.")

    category = clean_text(entry.get("category"), "Category", 100)
    classification = clean_text(entry.get("classification"), "Classification", 20)
    rate_basis = clean_text(entry.get("rateBasis"), "Rate basis", 100)
    rd = clean_text(entry.get("rd"), "R&D status", 10)
    status = clean_text(entry.get("status"), "Payment status", 50)
    confidence = clean_text(entry.get("confidence"), "Confidence", 100)

    if category not in ALLOWED_CATEGORIES:
        raise ValueError("Invalid activity category.")
    if classification not in ALLOWED_CLASSIFICATIONS:
        raise ValueError("Invalid classification.")
    if rate_basis not in ALLOWED_RATE_BASIS:
        raise ValueError("Invalid rate basis.")
    if rd not in ALLOWED_RD:
        raise ValueError("Invalid R&D status.")
    if status not in ALLOWED_STATUS:
        raise ValueError("Invalid payment status.")
    if confidence not in ALLOWED_CONFIDENCE:
        raise ValueError("Invalid confidence value.")

    return {
        "id": entry_id,
        "date": date,
        "start": entry.get("start") or "",
        "end": entry.get("end") or "",
        "hours": round(hours, 4),
        "project": clean_text(entry.get("project"), "Project", 200),
        "task": clean_text(entry.get("task"), "Task", 500),
        "category": category,
        "classification": classification,
        "rate": round(rate, 2),
        "rateBasis": rate_basis,
        "rd": rd,
        "status": status,
        "confidence": confidence,
        "evidence": clean_text(entry.get("evidence"), "Evidence", 1000),
        "notes": clean_text(entry.get("notes"), "Notes", 5000),
    }


def validate_settings(data):
    if not isinstance(data, dict):
        raise ValueError("Settings must be a JSON object.")

    start_date = data.get("startDate")
    if not validate_date(start_date):
        raise ValueError("Tracking start date must be YYYY-MM-DD.")

    rate = finite_number(data.get("defaultRate"), "Default rate")
    if rate < 0 or rate > 500:
        raise ValueError("Default rate must be between $0 and $500/hr.")

    return {
        "name": clean_text(data.get("name"), "Startup name", 200),
        "founder": clean_text(data.get("founder"), "Founder", 200),
        "defaultRate": round(rate, 2),
        "startDate": start_date,
    }


def row_to_entry(row):
    return {
        "id": row["id"],
        "date": row["date"],
        "start": row["start_time"],
        "end": row["end_time"],
        "hours": row["hours"],
        "project": row["project"],
        "task": row["task"],
        "category": row["category"],
        "classification": row["classification"],
        "rate": row["rate"],
        "rateBasis": row["rate_basis"],
        "rd": row["rd"],
        "status": row["status"],
        "confidence": row["confidence"],
        "evidence": row["evidence"],
        "notes": row["notes"],
    }


def client_key():
    return request.remote_addr or "unknown"


def login_allowed():
    now = time.monotonic()
    record = LOGIN_ATTEMPTS.get(client_key())
    if not record:
        return True
    if now - record["first"] > LOGIN_WINDOW_SECONDS:
        LOGIN_ATTEMPTS.pop(client_key(), None)
        return True
    return record["locked_until"] <= now and record["failures"] < MAX_FAILED_ATTEMPTS


def record_login_failure():
    now = time.monotonic()
    record = LOGIN_ATTEMPTS.get(client_key())
    if not record or now - record["first"] > LOGIN_WINDOW_SECONDS:
        LOGIN_ATTEMPTS[client_key()] = {"first": now, "failures": 1, "locked_until": 0}
        return
    record["failures"] += 1
    if record["failures"] >= MAX_FAILED_ATTEMPTS:
        record["locked_until"] = now + LOCKOUT_SECONDS


def clear_login_failures():
    LOGIN_ATTEMPTS.pop(client_key(), None)


def authenticate(role, password):
    user = USERS.get(role)
    return bool(user and user["password_hash"] and check_password_hash(user["password_hash"], password))


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("role"):
            return json_error("Authentication required.", 401)
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            return json_error("Admin role required.", 403)
        return view(*args, **kwargs)
    return wrapped


def csrf_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        expected = session.get("csrf_token")
        supplied = request.headers.get("X-CSRF-Token")
        if not expected or not supplied or not secrets.compare_digest(expected, supplied):
            return json_error("Invalid CSRF token.", 403)
        return view(*args, **kwargs)
    return wrapped


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "frame-ancestors 'none'"
    )
    return response


@app.errorhandler(413)
def request_too_large(_):
    return json_error("Request body is too large.", 413)


@app.route("/")
def index():
    return send_from_directory(PUBLIC_DIR, "index.html")


@app.route("/api/login", methods=["POST"])
def login():
    if not login_allowed():
        return json_error("Too many failed attempts. Try again in about 60 seconds.", 429)

    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        record_login_failure()
        return json_error("Invalid JSON body.", 400)

    role = data.get("role")
    password = data.get("password")

    if not isinstance(role, str) or not isinstance(password, str):
        record_login_failure()
        return json_error("Role and password are required.", 400)

    if not authenticate(role, password):
        record_login_failure()
        return json_error("Invalid credentials.", 401)

    clear_login_failures()
    session.clear()
    session["role"] = role
    session["csrf_token"] = secrets.token_urlsafe(32)

    return jsonify({"ok": True, "role": role, "csrfToken": session["csrf_token"]})


@app.route("/api/me", methods=["GET"])
@login_required
def me():
    return jsonify({"ok": True, "role": session["role"], "csrfToken": session["csrf_token"]})


@app.route("/api/logout", methods=["POST"])
@login_required
@csrf_required
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/state", methods=["GET"])
@login_required
def state():
    db = get_db()
    settings = db.execute(
        "SELECT name, founder, default_rate, start_date FROM settings WHERE id = 1"
    ).fetchone()
    entries = db.execute("SELECT * FROM entries ORDER BY date DESC, rowid DESC").fetchall()

    return jsonify({
        "settings": {
            "name": settings["name"],
            "founder": settings["founder"],
            "defaultRate": settings["default_rate"],
            "startDate": settings["start_date"],
        },
        "entries": [row_to_entry(row) for row in entries],
    })


@app.route("/api/entries", methods=["GET"])
@login_required
def entries():
    db = get_db()
    rows = db.execute("SELECT * FROM entries ORDER BY date DESC, rowid DESC").fetchall()
    return jsonify([row_to_entry(row) for row in rows])


@app.route("/api/entries", methods=["POST"])
@login_required
@csrf_required
def create_entry():
    try:
        entry = normalize_entry(request.get_json(silent=True))
    except (TypeError, ValueError) as exc:
        return json_error(str(exc), 400)

    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    db = get_db()
    try:
        db.execute("""
            INSERT INTO entries (
                id, date, start_time, end_time, hours, project, task, category,
                classification, rate, rate_basis, rd, status, confidence,
                evidence, notes, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entry["id"], entry["date"], entry["start"], entry["end"], entry["hours"],
            entry["project"], entry["task"], entry["category"], entry["classification"],
            entry["rate"], entry["rateBasis"], entry["rd"], entry["status"],
            entry["confidence"], entry["evidence"], entry["notes"], now, now
        ))
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        return json_error("Entry ID already exists.", 409)

    return jsonify({"ok": True, "entry": entry}), 201


@app.route("/api/entries/<entry_id>", methods=["PUT"])
@login_required
@csrf_required
def update_entry(entry_id):
    try:
        entry = normalize_entry(request.get_json(silent=True))
    except (TypeError, ValueError) as exc:
        return json_error(str(exc), 400)

    entry["id"] = entry_id
    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    db = get_db()
    result = db.execute("""
        UPDATE entries
        SET date=?, start_time=?, end_time=?, hours=?, project=?, task=?, category=?,
            classification=?, rate=?, rate_basis=?, rd=?, status=?, confidence=?,
            evidence=?, notes=?, updated_at=?
        WHERE id=?
    """, (
        entry["date"], entry["start"], entry["end"], entry["hours"], entry["project"], entry["task"],
        entry["category"], entry["classification"], entry["rate"], entry["rateBasis"], entry["rd"],
        entry["status"], entry["confidence"], entry["evidence"], entry["notes"], now, entry_id
    ))
    db.commit()

    if result.rowcount == 0:
        return json_error("Entry not found.", 404)

    return jsonify({"ok": True, "entry": entry})


@app.route("/api/entries/<entry_id>", methods=["DELETE"])
@login_required
@csrf_required
def delete_entry(entry_id):
    db = get_db()
    result = db.execute("DELETE FROM entries WHERE id = ?", (entry_id,))
    db.commit()
    if result.rowcount == 0:
        return json_error("Entry not found.", 404)
    return jsonify({"ok": True})


@app.route("/api/entries/bulk", methods=["POST"])
@login_required
@admin_required
@csrf_required
def bulk_create():
    data = request.get_json(silent=True)
    if not isinstance(data, list):
        return json_error("Request body must be a JSON array.", 400)

    clean_entries = []
    seen = set()
    try:
        for raw in data:
            entry = normalize_entry(raw)
            if entry["id"] in seen:
                raise ValueError("Duplicate entry ID in request.")
            seen.add(entry["id"])
            clean_entries.append(entry)
    except (TypeError, ValueError) as exc:
        return json_error(str(exc), 400)

    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    db = get_db()
    try:
        with db:
            for entry in clean_entries:
                db.execute("""
                    INSERT INTO entries (
                        id, date, start_time, end_time, hours, project, task, category,
                        classification, rate, rate_basis, rd, status, confidence,
                        evidence, notes, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry["id"], entry["date"], entry["start"], entry["end"], entry["hours"],
                    entry["project"], entry["task"], entry["category"], entry["classification"],
                    entry["rate"], entry["rateBasis"], entry["rd"], entry["status"],
                    entry["confidence"], entry["evidence"], entry["notes"], now, now
                ))
    except sqlite3.IntegrityError:
        db.rollback()
        return json_error("One or more entry IDs already exist.", 409)

    return jsonify({"ok": True, "count": len(clean_entries)}), 201


@app.route("/api/entries", methods=["DELETE"])
@login_required
@admin_required
@csrf_required
def delete_all_entries():
    db = get_db()
    db.execute("DELETE FROM entries")
    db.commit()
    return jsonify({"ok": True})


@app.route("/api/settings", methods=["POST"])
@login_required
@csrf_required
def save_settings():
    try:
        settings = validate_settings(request.get_json(silent=True))
    except (TypeError, ValueError) as exc:
        return json_error(str(exc), 400)

    db = get_db()
    db.execute("""
        UPDATE settings
        SET name=?, founder=?, default_rate=?, start_date=?
        WHERE id=1
    """, (settings["name"], settings["founder"], settings["defaultRate"], settings["startDate"]))
    db.commit()
    return jsonify({"ok": True})


def validate_settings(data):
    if not isinstance(data, dict):
        raise ValueError("Settings must be a JSON object.")

    start_date = data.get("startDate")
    if not validate_date(start_date):
        raise ValueError("Tracking start date must be YYYY-MM-DD.")

    rate = finite_number(data.get("defaultRate"), "Default rate")
    if rate < 0 or rate > 500:
        raise ValueError("Default rate must be between $0 and $500/hr.")

    return {
        "name": clean_text(data.get("name"), "Startup name", 200),
        "founder": clean_text(data.get("founder"), "Founder", 200),
        "defaultRate": round(rate, 2),
        "startDate": start_date,
    }


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=8000, debug=False)
