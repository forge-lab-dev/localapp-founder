# Startup Hours & Sweat Equity Tracker — Corrected Editions

This package contains:

1. `v1_secure_json/` — safest low-disruption replacement for the current application.
   - Keeps `data.json`
   - Keeps localhost:8000
   - Keeps the current UI/functionality
   - Adds real sessions, CSRF, password hashing, server validation, safe DOM rendering, atomic writes, and security headers.

2. `v2_sqlite/` — recommended long-term local version.
   - Replaces JSON persistence with SQLite.
   - Uses transactional CRUD APIs.
   - Supports migration from the current data.json.
   - Keeps the same UI and localhost workflow.

## Recommended path

Run V1 first and confirm behavior/data.

Then copy `data.json` into `v2_sqlite/` and run:

```powershell
python migrate_json_to_sqlite.py
python app.py
```

The migration tool does not modify or delete the original `data.json`.

## Important

The provided credentials are not hard-coded. Generate password hashes with `setup_passwords.py` and place the resulting hashes in environment variables.

For a persistent session secret, set `FLASK_SECRET_KEY`.

This remains a localhost-only application: both versions bind to `127.0.0.1:8000`.
